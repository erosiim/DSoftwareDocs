<?php

//Remplazar postgres por su nombre de usuario de postgres

//Y remplazar 211215 por su contraseña de postgres

$conn = new PDO("pgsql:host=localhost;dbname=metropolitanoUsuarios","postgres","211215")

?>