<header>
    <a href="/php-login">Your Name App</a>
</header>